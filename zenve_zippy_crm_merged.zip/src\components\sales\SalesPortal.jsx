import '../sfa/sfa.css';
import SFAApp from '../sfa/SFAApp.jsx';

/**
 * SalesPortal — entry point wired to the "Sales CRM" button in TopBar.
 * Now renders the full Torrent SFA (Sales Executive Portal) instead of the
 * old built-in sales login/dashboard.
 */
export default function SalesPortal({ onExitToAdmin }) {
  return <SFAApp onExitToAdmin={onExitToAdmin} />;
}
