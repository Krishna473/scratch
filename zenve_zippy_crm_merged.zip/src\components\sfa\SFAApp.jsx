import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import ProfileView from './components/ProfileView';
import DailyReportingView from './components/DailyReportingView';
import DoctorCallModal from './components/DoctorCallModal';
import DashboardView from './components/DashboardView';
import OrderBookingView from './components/OrderBookingView';
import DoctorMasterView from './components/DoctorMasterView';
import Toast from './components/Toast';
import { initialProfileData, initialDoctors, sampleOrders } from './data/mockData';

export default function SFAApp({ onExitToAdmin }) {
  const [currentView, setCurrentView] = useState(() => {
    return localStorage.getItem('sfa_current_view') || 'reporting';
  });

  const [profile, setProfile] = useState(() => {
    const saved = localStorage.getItem('sfa_profile');
    return saved ? JSON.parse(saved) : initialProfileData;
  });

  const [doctors, setDoctors] = useState(() => {
    const saved = localStorage.getItem('sfa_doctors');
    return saved ? JSON.parse(saved) : initialDoctors;
  });

  const [orders, setOrders] = useState(() => {
    const saved = localStorage.getItem('sfa_orders');
    return saved ? JSON.parse(saved) : sampleOrders;
  });

  const [selectedDoctorForModal, setSelectedDoctorForModal] = useState(null);
  const [toast, setToast] = useState(null);

  useEffect(() => {
    localStorage.setItem('sfa_current_view', currentView);
  }, [currentView]);

  useEffect(() => {
    localStorage.setItem('sfa_profile', JSON.stringify(profile));
  }, [profile]);

  useEffect(() => {
    localStorage.setItem('sfa_doctors', JSON.stringify(doctors));
  }, [doctors]);

  useEffect(() => {
    localStorage.setItem('sfa_orders', JSON.stringify(orders));
  }, [orders]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const handleUpdateProfile = (updatedData) => setProfile(updatedData);

  const handleAddDoctorToDaily = (doctorId) => {
    setDoctors(prev =>
      prev.map(doc => (doc.id === doctorId ? { ...doc, planned: false } : doc))
    );
  };

  const handleRemoveDoctorFromDaily = (doctorId) => {
    setDoctors(prev => prev.filter(doc => doc.id !== doctorId));
  };

  const handleSaveDoctorCall = (doctorId, callDetails) => {
    setDoctors(prev =>
      prev.map(doc =>
        doc.id === doctorId ? { ...doc, status: 'Reported', callDetails } : doc
      )
    );
  };

  const handleAddOrder = (newOrder) => {
    setOrders(prev => [newOrder, ...prev]);
  };

  const handleFinalSubmitDCR = () => {
    setDoctors(prev => prev.map(doc => ({ ...doc, status: 'Reported' })));
  };

  return (
    <div className="min-h-screen bg-[#f4f6f8] flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Back to Admin CRM button */}
      <div className="bg-slate-800 text-white text-xs py-1.5 px-4 flex items-center justify-between">
        <span className="text-slate-300">You are viewing the Sales Executive Portal (SFA)</span>
        <button
          onClick={onExitToAdmin}
          className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white rounded text-xs font-semibold transition-colors flex items-center gap-1.5"
        >
          ← Back to Admin CRM
        </button>
      </div>

      <Header
        currentView={currentView}
        setCurrentView={setCurrentView}
        profile={profile}
        showToast={showToast}
      />

      <main className="flex-1">
        {currentView === 'reporting' && (
          <DailyReportingView
            doctors={doctors}
            onAddDoctor={handleAddDoctorToDaily}
            onRemoveDoctor={handleRemoveDoctorFromDaily}
            onOpenCallModal={(doc) => setSelectedDoctorForModal(doc)}
            onFinalSubmitDCR={handleFinalSubmitDCR}
            showToast={showToast}
          />
        )}
        {currentView === 'profile' && (
          <ProfileView
            profile={profile}
            onUpdateProfile={handleUpdateProfile}
            showToast={showToast}
          />
        )}
        {currentView === 'dashboard' && (
          <DashboardView
            profile={profile}
            doctors={doctors}
            orders={orders}
            setCurrentView={setCurrentView}
            onOpenCallModal={(doc) => setSelectedDoctorForModal(doc)}
          />
        )}
        {currentView === 'orders' && (
          <OrderBookingView
            orders={orders}
            onAddOrder={handleAddOrder}
            showToast={showToast}
          />
        )}
        {currentView === 'doctors' && (
          <DoctorMasterView
            doctors={doctors}
            onOpenCallModal={(doc) => setSelectedDoctorForModal(doc)}
            setCurrentView={setCurrentView}
          />
        )}
      </main>

      {selectedDoctorForModal && (
        <DoctorCallModal
          doctor={selectedDoctorForModal}
          onClose={() => setSelectedDoctorForModal(null)}
          onSaveCall={handleSaveDoctorCall}
          showToast={showToast}
        />
      )}

      <Toast toast={toast} onClose={() => setToast(null)} />

      {/* Floating Bottom Quick Switcher */}
      <footer className="fixed bottom-3 left-1/2 transform -translate-x-1/2 z-30 bg-slate-900/90 text-white backdrop-blur-md px-4 py-2 rounded-full shadow-2xl border border-white/20 flex items-center gap-1 sm:gap-3 text-xs">
        <span className="text-gray-400 font-semibold text-[11px] hidden sm:inline mr-1">View:</span>
        {[
          { key: 'reporting', label: 'Daily Reporting' },
          { key: 'profile', label: 'My Profile' },
          { key: 'dashboard', label: 'Dashboard' },
          { key: 'orders', label: 'Order POB' },
          { key: 'doctors', label: 'Doctor Master' },
        ].map(({ key, label }) => (
          <button
            key={key}
            onClick={() => setCurrentView(key)}
            className={`px-3 py-1 rounded-full transition-all ${
              currentView === key
                ? 'bg-blue-600 text-white font-bold shadow-xs'
                : 'text-gray-300 hover:text-white'
            }`}
          >
            {label}
          </button>
        ))}
      </footer>
    </div>
  );
}
